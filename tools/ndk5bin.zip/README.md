## how to use?
This ELF provides support for Android 5-6, the default source code only supports Android 6+.  
Just replace to assets/bin/ .  

此ELF为Android5-6提供支持,默认的源码仅支持安卓6+  
直接替换到assets/bin/即可  